﻿using System;
using System.Collections.Generic;
using System.Linq;
using ThirdPartyTools;

namespace FileData
{
    public static class Program
    {
        public static void Main(string[] args)
        {
            FileDetails ThirdPartyToolsFileDetails = new FileDetails();

            string firstArgument = args[0];
            string secondArgument = args[1];

            string fileVersion = "";

            if (firstArgument == "-v")
            {
                fileVersion = ThirdPartyToolsFileDetails.Version(secondArgument);
                fileVersion = " File version is " + fileVersion;
            }
            else
            {
                fileVersion = "The first argument must be -v";
            }

            Console.WriteLine(fileVersion);
            Console.ReadKey();
        }
    }
}
