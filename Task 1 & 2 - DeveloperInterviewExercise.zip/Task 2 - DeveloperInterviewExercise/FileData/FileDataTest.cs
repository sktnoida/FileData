﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FileData
{
    class FileDataTest
    {
        public IsVaildInput TestInput(string[] args)
        {
            string firstArgument = args[0];
            string secondArgument = args[1];

            StringBuilder sbMsg = new StringBuilder("");


            // `-v`, `--v`, `/v`, `--version`


            IsVaildInput objInput = new IsVaildInput();

            //first Argument
            if (firstArgument == null)
            {
                sbMsg.Append("First argument can not be blank.").Append(Environment.NewLine);
            }
            else
            {
                string firstValidInput = ",-v,--v,/v,--version,";
                string[] firstValidInputList = firstValidInput.Split(',');

                if (firstValidInputList.Contains(firstArgument))
                {
                    objInput.IsVaild = true;
                }
                else
                {
                    sbMsg.Append("First valid argument are").Append(firstValidInput).Append(Environment.NewLine);
                }
            }



            //second Argument
            if (secondArgument == null)
            {
                objInput.IsVaild = false;
                sbMsg.Append("Second argument can not be blank.").Append(Environment.NewLine);
            }
            else
            {
                string secondValidInput = "-s,--s,/s,--size";
                string[] secondValidInputList = secondValidInput.Split(',');

                if (secondValidInputList.Contains(secondArgument))
                {
                    objInput.IsVaild = true;
                }
                else
                {
                    sbMsg.Append("Second valid argument are").Append(secondValidInput).Append(Environment.NewLine);
                }
            }

            objInput.Msg = sbMsg.ToString();

            return objInput;

        }

    }



    class IsVaildInput
    {

        public bool IsVaild { get; set; }
        public string Msg { get; set; }

        public IsVaildInput()
        {
            IsVaild = false;
        }
    }

}
