﻿using System;
using System.Collections.Generic;
using System.Linq;
using ThirdPartyTools;

namespace FileData
{
    public static class Program
    {
        public static void Main(string[] args)
        {

            FileDataTest objTest = new FileDataTest();
            IsVaildInput objInput = objTest.TestInput(args);
            string fileVersion = "";

            if (objInput.IsVaild)
            {
                FileDetails ThirdPartyToolsFileDetails = new FileDetails();

                string firstArgument = args[0];
                string secondArgument = args[1];

                fileVersion = ThirdPartyToolsFileDetails.Version(secondArgument);
                fileVersion = " File version is " + fileVersion;

            }
            else
            {
                fileVersion = objInput.Msg;
            }




            Console.WriteLine(fileVersion);
            Console.ReadKey();
        }
    }
}
